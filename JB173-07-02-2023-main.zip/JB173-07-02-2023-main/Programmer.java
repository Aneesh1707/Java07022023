package oops;

public class Programmer extends Employee{
	int bonus=2000;

}
