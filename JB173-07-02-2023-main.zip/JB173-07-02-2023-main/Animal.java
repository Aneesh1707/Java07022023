package oops;

public class Animal {
	String color="Black";
	
	void eat()
	{
		System.out.println("Eating...");
	}

}
