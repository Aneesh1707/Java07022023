package oops;

public class Dog extends Animal {
	
	void bark()
	{
		System.out.println("Barking...");
	}

}
