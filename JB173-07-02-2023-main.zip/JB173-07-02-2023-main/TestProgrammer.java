package oops;

public class TestProgrammer {

	public static void main(String[] args) {

		
		Programmer programmer=new Programmer();
		System.out.println(programmer.salary);//super class
		System.out.println(programmer.bonus);//child class
	}

}
