package oops;

public class Employee {
	float salary=40000;

}
