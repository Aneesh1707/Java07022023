package oops;

public class Cat extends Animal{
	
	void sleep()
	{
		System.out.println("Sleeping");
	}

}
