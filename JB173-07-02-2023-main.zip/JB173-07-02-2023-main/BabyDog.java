package oops;

public class BabyDog extends Dog {
	void cry()
	{
		System.out.println("Crying");
	}

}
